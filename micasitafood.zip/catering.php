<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0, user-scalable=no">
    <title>Mi Casita Food- Online Order Restaurants |Catering Services Denton TX</title>
    <meta name="description" content="">
    <meta name="keywords" content="" >

    <?php include("includes/top-header.php");?>

</head>

<body class="sticky-menu">

    <div class="wrapper">

     <?php include("includes/header.php");?>
     <section class="page-title mvb0" data-bg-image="images/pages/cover12.jpg">
        <div class="overlay" data-bg-color="#101010"></div>
        <div class="container">
            <div class="row">
                <div class="col-sm-12">
                    <h3>Catering</h3>
                </div>
            </div>
        </div>

    </section>

    <section class="section-content">

        <div class="content-full">

            <div class="fullscreen-section">
                <div class="container-fluid">
                    <div class="row">

                        <div class="col-sm-6 pv4 text-center cater" data-bg-color="#1e1e1e">
                            <div class="heading text-center cater">
                                <h3>Fajita Plates</h3>
                                <h4>$16.50 Per Person </h4>
                            </div>

                            <p>
                                Includes - choice of meat, beef, chicken or combination, Rice, beans, tortillas, guacamole, sour cream, pico, salad, cheese. Lime, cilantro, onions, limes. Chips and salsa. 
                            </p>

                            <div class="heading text-center cater">
                                <h3>Taco Bar</h3>
                                <h4>$12.50 Per Person </h4>
                            </div>

                            <p>
                                Includes - Beef, chicken, or both. 2 tacos Taco shells, soft flour tortillas, Rice, beans, tomato, lettuce, cheese, jalapeños, cilantro, onions, Chips and salsa.
                            </p>

                            <div class="heading text-center cater">
                                <h3>Enchilada Plates</h3>
                                <h4>$12.50 Per Person </h4>
                            </div>

                            <p>
                                Includes - chicken, cheese, beef enchiladas 2 per plates rice, beans, cilantro, onions, jalapeños, Chips and salsa.
                            </p>
                        </div>

                        <div class="col-sm-6 pv14 ph5 cater bg-cover bg-center-top d-none" data-bg-image="images/pages/h5-coffee.jpg">
                            <div>
                                <div class="heading text-center">
                                    <h3>Experienced Catering</h3>
                                </div>

                                <p>
                                   When you're getting ready to host your next event or celebration, you want everything to be perfect. That's why we offer experienced catering services ideal for any occasion.
                                </p>

                                <h6>* We would add plates, forks, napkins, and sweet tea and unsweetened tea with extra charge per person.</h6>
                            <h6>* We add a 15% delivery charge to all our delivery and setup orders. </h6>
                            </div>
                        </div>
                    </div>
                </div>
            </div>


            <div class="fullscreen-section pv4 bg-contain bg-center-top" data-bg-image="images/pages/cover11.jpg">


                <div class="container-large pv4 pvb0">
                    <div class="row">
                        <div class="col-sm-3">
                            <div class="blog-grid-item">
                                <div class="entry-date"><span>Birthdays</span></div>
                                <a href="contact-us.php" class="entry-image">
                                    <img src="images/catering-1.jpg" alt="blog image">
                                </a>
                            </div>
                        </div>
                        <div class="col-sm-3">
                            <div class="blog-grid-item">
                                <div class="entry-date"><span>Anniversaries</span></div>
                                <a href="contact-us.php" class="entry-image">
                                    <img src="images/catering-2.jpg" alt="blog image">
                                </a>
                            </div>
                        </div>
                        <div class="col-sm-3">
                            <div class="blog-grid-item">
                                <div class="entry-date"><span>Graduations</span></div>
                                <a href="contact-us.php" class="entry-image">
                                    <img src="images/catering-3.jpg" alt="blog image">
                                </a>
                            </div>
                        </div>
                        <div class="col-sm-3">
                            <div class="blog-grid-item">
                                <div class="entry-date"><span>Company Parties</span></div>
                                <a href="contact-us.php" class="entry-image">
                                    <img src="images/catering-4.jpg" alt="blog image">
                                </a>
                            </div>
                        </div>
                        <div class="col-sm-3">
                            <div class="blog-grid-item">
                                <div class="entry-date"><span>Quinceaneras</span></div>
                                <a href="contact-us.php" class="entry-image">
                                    <img src="images/catering-5.jpg" alt="blog image">
                                </a>
                            </div>
                        </div>
                        <div class="col-sm-3">
                            <div class="blog-grid-item">
                                <div class="entry-date"><span>Weddings</span></div>
                                <a href="contact-us.php" class="entry-image">
                                    <img src="images/catering-6.jpg" alt="blog image">
                                </a>
                            </div>
                        </div>
                        <div class="col-sm-3">
                            <div class="blog-grid-item">
                                <div class="entry-date"><span>AND MORE!</span></div>
                                <a href="contact-us.php" class="entry-image">
                                    <img src="images/catering-7.jpg" alt="blog image">
                                </a>
                            </div>
                        </div>
                    </div>
                </div>

            </div>



        </div>

    </section>


    <?php include("includes/footer.php");?>



</body>
</html>