<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0, user-scalable=no">
    <title>Mi Casita Food- Online Order Restaurants |Catering Services Denton TX</title>
    <meta name="description" content="">
    <meta name="keywords" content="" >

    <?php include("includes/top-header.php");?>

</head>

<body class="sticky-menu">

    <div class="wrapper">

     <?php include("includes/header.php");?>
     <section class="page-title mvb0" data-bg-image="images/pages/cover12.jpg">
        <div class="overlay" data-bg-color="#101010"></div>
        <div class="container">
            <div class="row">
                <div class="col-sm-12">
                    <h3>Breakfast</h3>
                    <h5>When you're looking for a delicious way to start your day, stop into Mi Casita for a mouthwatering, hearty breakfast.</h5>
                    <h4>*Prices Subject To Change</h4>
                </div>
            </div>
        </div>

    </section>

    <section class="section-content fullscreen-section">

        <div class="fullwidth-tabs pv4 bg-contain bg-center-top size" data-bg-color="#FAFAFA" data-bg-image="images/pages/cover17.jpg">
            <div>
                <div class="container tabs-nav">
                    <div class="row">
                        <div class="col-md-12 text-center">
                            <ul>
                                <li class="active"><a href="javascript:;">Breakfast Tacos</a></li>
                                <li><a href="javascript:;">Breakfast Plates</a></li>
                                <li><a href="javascript:;">Soft Drinks</a></li>
                                <li><a href="javascript:;">Juices</a></li>
                                <li><a href="javascript:;">Sweet &amp; Unsweetened Tea</a></li>
                                <li><a href="javascript:;">Mexican Bottled Drinks</a></li>
                                <li><a href="javascript:;">Coffee</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div>
                <div class="container tabs-contents">
                    <div class="tabs-content">
                        <div class="row pv6 pvb0">
                            <div class="col-md-12 mv5 mvt0">

                                <div class="heading text-center">
                                    <h3>Breakfast Tacos</h3>
                                </div>

                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-5 ph3">
                                <div class="food-price">
                                    <h4>Chorizo &amp; Egg <span class="fp-amount">$2.67</span></h4>
                                </div>
                                <div class="food-price">
                                    <h4>Potato &amp; Egg <span class="fp-amount">$2.67</span></h4>
                                </div>
                                <div class="food-price">
                                    <h4>Bacon &amp; Egg <span class="fp-amount">$2.67</span></h4>
                                </div>
                            </div>
                            <div class="col-md-5 ph3">
                                <div class="food-price">
                                    <h4>Ham &amp; Egg <span class="fp-amount">$2.67</span></h4>
                                </div>
                                <div class="food-price">
                                    <h4>Sausage &amp; Egg <span class="fp-amount">$2.67</span></h4>
                                </div>
                                <div class="food-price">
                                    <h4>With cheese <span class="fp-amount">$2.67</span></h4>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="tabs-content">
                        <div class="row pv6 pvb0">
                            <div class="col-md-12 mv5 mvt0">
                                <div class="heading text-center">
                                    <h3>Breakfast Plates</h3>
                                </div>

                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-5 ph3">
                                <h3 class="sub-head">Huevos Rancheros</h3>
                                <div class="food-price">
                                    <h4>- With 2 eggs <span class="fp-amount">$8.99</span></h4>
                                </div>
                                <div class="food-price">
                                    <h4>- With 3 eggs <span class="fp-amount">$9.99</span></h4>
                                </div>
                                <div class="food-price">
                                    <h4>- With 3 eggs <span class="fp-amount">$9.99</span></h4>
                                </div>
                                <div class="food-price">
                                    <h4>- With cheese<span class="fp-amount">$98.99</span></h4>
                                </div>
                            </div>
                            <div class="col-md-5 ph3">
                                <h3 class="sub-head">Migas</h3>
                                <div class="food-price">
                                    <h4>- With 2 eggs <span class="fp-amount">$8.99</span></h4>
                                </div>
                                <div class="food-price">
                                    <h4>- With 3 eggs <span class="fp-amount">$9.99</span></h4>
                                </div>
                                <div class="food-price">
                                    <p>Plain <span class="fp-amount">$4.49</span></p>
                                </div>
                                <div class="food-price">
                                    <p>Ham &amp; Egg <span class="fp-amount">$4.99</span></p>
                                </div>
                                <div class="food-price">
                                    <p>Bacon &amp; Egg <span class="fp-amount">$4.99</span></p>
                                </div>
                                <div class="food-price">
                                    <p>Sausage &amp; Egg <span class="fp-amount">$4.99</span></p>
                                </div>
                                <div class="food-price">
                                    <p>With cheese <span class="fp-amount">$5.49</span></p>
                                </div>
                              
                            </div>
                        </div>
                    </div>
                    <div class="tabs-content">
                        <div class="row pv6 pvb0">
                            <div class="col-md-12 mv5 mvt0">

                                <div class="heading text-center">
                                    <h3>Soft Drinks</h3>
                                </div>

                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-5 ph3">
                                <div class="food-price">
                                    <h4>Large (32 oz) <span class="fp-amount">$2.77</span></h4>
                                </div>
                                <div class="food-price">
                                    <h4>Chocolate Milk (16 oz) <span class="fp-amount">$3.99</span></h4>
                                </div>
                            </div>
                            <div class="col-md-5 ph3">
                                <div class="food-price">
                                    <h4>Horchata 32 oz <span class="fp-amount">$3.49</span></h4>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="tabs-content">
                        <div class="row pv6 pvb0">
                            <div class="col-md-12 mv5 mvt0">

                                <div class="heading text-center">
                                    <h3>Juices</h3>
                                </div>

                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-5 ph3">

                                <div class="food-price">
                                    <h4>Small <span class="fp-amount">$2.99</span></h4>
                                </div>

                            </div>
                            <div class="col-md-5 ph3">
                                <div class="food-price">
                                    <h4>Large <span class="fp-amount">$3.59</span></h4>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="tabs-content">
                        <div class="row pv6 pvb0">
                            <div class="col-md-12 mv5 mvt0">

                                <div class="heading text-center">
                                    <h3>Sweet &amp; Unsweetened Tea</h3>
                                </div>

                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-5 ph3">

                                <div class="food-price">
                                    <h4>Large <span class="fp-amount">$2.77</span></h4>
                                </div>
                            </div>
                            <div class="col-md-5 ph3">
                                <div class="food-price">
                                    <h4>Gallon <span class="fp-amount">$9.99</span></h4>
                                    <p>- (w/cheese) <span class="fp-amount">$3.29</span></p>
                                    <p>- (w/Beans Added) <span class="fp-amount">$3.29</span></p>
                                    <p>- (w/cheese) <span class="fp-amount">$3.49</span></p>
                                </div>

                            </div>
                        </div>
                    </div>
                    <div class="tabs-content">
                        <div class="row pv6 pvb0">
                            <div class="col-md-12 mv5 mvt0">

                                <div class="heading text-center">
                                    <h3>Mexican Bottled Drinks</h3>
                                </div>

                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-5 ph3">

                                <div class="food-price">
                                    <h4>Half a liter <span class="fp-amount">$3.49</span></h4>
                                </div>
                            </div>
                            <div class="col-md-5 ph3">
                                <div class="food-price">
                                    <h4>Reg (12 oz) soda <span class="fp-amount">$2.99</span></h4>
                                </div>

                            </div>
                        </div>
                    </div>
                    <div class="tabs-content">
                        <div class="row pv6 pvb0">
                            <div class="col-md-12 mv5 mvt0">

                                <div class="heading text-center">
                                    <h3>Coffee</h3>
                                </div>

                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-5 ph3">
                                <div class="food-price">
                                    <h4>Coffee <span class="fp-amount">$2.59</span></h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>


    </div>

</section>


<?php include("includes/footer.php");?>



</body>
</html>