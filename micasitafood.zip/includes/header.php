 <header id="header" class="menu-below-logo">

            <div class="container">
                <div class="row">
                    <div class="col-sm-12">

                        <div class="header-wrapper">

                            <!-- <a href="./" id="logo" title="" class="logo-image" data-bg-image="images/logo.png"></a> -->
                            <a href="./" id="logo" class="logo-image"><img src="images/logo.png"></a>
                            <div class="topbar-left-content">
                                <ul>
                                    <li><a href="https://maps.app.goo.gl/g3dCipnGzPXL1NSaA" target="_blank"><i class="fa fa-map-marker"></i> 110 North Carroll, Blvd Denton, TX 76201</a></li>
                                    
                                </ul>
                            </div>

                            <div class="topbar-right-content">
                                <ul>
                                    <li><a href="tel:9408911932"><i class="fa fa-phone"></i> (940) 891-1932 </a></li>
                                    <li class="dis"><a href="https://www.facebook.com/micasitadenton/" target="_blank"><img src="images/facebook.jpg"></a></li>

                                </ul>
                            </div>

                        </div>

                    </div>
                </div>
            </div>

            <nav class="main-nav">
                <ul>
                    <li class="menu-item-has-children">
                        <a href="./">Home</a>
                    </li>
                    <li class="menu-item-has-children">
                        <a href="#">Our Menu</a>
                        <ul>
                            <li><a href="lunch-dinner.php">Lunch / Dinner</a></li>
                            <li><a href="breakfast.php">Breakfast</a></li>
                        </ul>
                    </li>
                    <li><a href="catering.php">Catering</a></li>
                    <li><a href="gallery.php">Gallery</a></li>
                    <li><a href="https://zingmyorder.com/restaurants/Mi-Casita-Mexican-Food" target="_blank">Order Online</a></li>
                    <li><a href="contact-us.php">Contact Us</a></li>
                </ul>

                <a href="javascript:;" id="mobile-menu">
                    Menu
                    <span>
                        <span></span>
                        <span></span>
                        <span></span>
                    </span>
                </a>
                <a href="javascript:;" id="close-menu"></a>
            </nav>

        </header>