<footer id="footer" class="footer-1" data-bg-image="images/pages/footer-1.png">

    <div class="sub-footer">
        <div class="container">
            <div class="row copyright-text">
                <div class="col-sm-12 text-center">
                    <p>&copy; 2023 Mi Casita Food. All Rights Reserved.<br>
            <a href="https://www.wxperts.co/website-development.php" target="_blank">Website Development</a> | <a href="https://www.wxperts.co/" target="_blank">Hosting</a> | <a href="https://www.wxperts.co/search-engine-optimization.php" target="_blank">SEO</a> | <a href="https://www.wxperts.co/digital-marketing.php" target="_blank">Digital Marketing</a>
            <br><a href="https://www.wxperts.co/" target="_blank"><img src="images/wxperts_powerdby.jpg" alt="webxperts"></a></p>
                </div>
            </div>
        </div>
    </div>
</footer>        
</div>

<!-- Include jQuery and Scripts -->
<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="vendors/bootstrap/js/bootstrap.min.js"></script>
<script type="text/javascript" src="vendors/jquery.waypoints.min.js"></script>
<script type="text/javascript" src="vendors/isotope.pkgd.min.js"></script>

<!-- Swiper -->
<script type="text/javascript" src="vendors/swiper/js/swiper.min.js"></script>

<!-- Magnific-popup -->
<script type="text/javascript" src="vendors/magnific-popup/jquery.magnific-popup.min.js"></script>

<script type="text/javascript" src="js/scripts.js"></script>