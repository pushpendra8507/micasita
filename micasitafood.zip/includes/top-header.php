<?php $protocol = ((!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] != 'off') || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
    $url = $protocol . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']; ?>
    <meta name="author" content="<?php echo isset($url)?$url:'' ?>"/>
    <meta name="robots" content="index, follow"/>
    <meta name="rating" content="safe for kids"/>
    <meta name="googlebot" content=" index, follow"/>
    <meta name="allow-search" content="yes"/>
    <meta name="revisit-after" content="daily"/>
    <meta name="language" content="en-US"/>
    <meta name="distribution" content="global"/>
    <link rel="canonical" href="<?php echo isset($url)?$url:'' ?>"/>


    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="images/favicon.png"/>

    <!-- Fonts -->
    <link href='https://fonts.googleapis.com/css?family=Merriweather:400,300,300italic,400italic,700,700italic,900,900italic%7CPlayball%7CMontserrat:400,700' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Playfair+Display:400,400italic' rel='stylesheet' type='text/css'>
    
    <!-- Bootstrap -->
    <link rel="stylesheet" type="text/css" href="vendors/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="vendors/bootstrap/css/bootstrap-theme.min.css">

    <!-- Fontawesome -->
    <link rel="stylesheet" type="text/css" href="vendors/font-awesome/css/font-awesome.min.css">

    <!-- Swiper -->
    <link rel="stylesheet" type="text/css" href="vendors/swiper/css/swiper.min.css">

    <!-- Magnific-popup -->
    <link rel="stylesheet" type="text/css" href="vendors/magnific-popup/magnific-popup.css">

    <!-- Stylesheet -->
    <link rel="stylesheet" type="text/css" href="style.css">