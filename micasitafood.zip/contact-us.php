<?php
include_once 'contactfunctions.php';

if(isset($_POST) && isset($_POST["btn_submit"]))
{
    if (!isset($_SERVER['HTTP_REFERER']) || (parse_url($_SERVER['HTTP_REFERER'], PHP_URL_HOST) != $_SERVER['SERVER_NAME'])) {
        echo '<script>window.location="./"</script>'; exit;
    }

    $name = $email = $phone = $service = $msge = "";
    if($_SERVER["REQUEST_METHOD"] == "POST")
    {

        $secretKey  = '6LdnCjMpAAAAAEE5M7dZ5AS_8IIFRLW3YStuy6s0';
        $token    = $_POST["g-token"];
        $ip     = $_SERVER['REMOTE_ADDR'];
      
        if(empty($_POST["name"]))
        {
            echo '<script>window.location="./"</script>'; exit;
        } 
        else
        {
            $name = filterName($_POST["name"]);
            if($name == FALSE){
                echo '<script>window.location="./"</script>'; exit;
            }
        }
    
        if(empty($_POST["email"]))
        {
            echo '<script>window.location="./"</script>'; exit;    
        } 
        else
        {
            $email = filterEmail($_POST["email"]);
            if($email == FALSE){
                echo '<script>window.location="./"</script>'; exit;
            }
        }

        $phone = (isset($_POST["phone"]) && !empty($_POST["phone"]))? $_POST["phone"]: '';
        $service = (isset($_POST["subject"]) && !empty($_POST["subject"]))? $_POST["subject"]: '';
       

        // Validate user message
        if(empty($_POST["description"]))
        {
            echo '<script>window.location="./"</script>'; exit;    
        } 
        else
        {
            $msge = filterString($_POST["description"]);
            if($msge == FALSE){
                echo '<script>window.location="./"</script>'; exit;
            }
        }
 
        $url = "https://www.google.com/recaptcha/api/siteverify";
        $data = array('secret' => $secretKey, 'response' => $token, 'remoteip'=> $ip);

          // use key 'http' even if you send the request to https://...
        $options = array('http' => array(
            'method'  => 'POST',
            'content' => http_build_query($data)
        ));
        $context  = stream_context_create($options);
        $result = file_get_contents($url, false, $context);
        $response = json_decode($result);
        //echo '<pre>';print_r($response);die();
        if($response->success)
        {
            define('BUSINESS_NAME','Mi Casita MEXICAN FOOD');
            define('FORM_TYPE','Contact Form');
            //  $to = '	matt@micasitafood.com';
             $to = 'ravi02.agp@gmail.com';
             $to = 'ghansraj82@gmail.com';
            $fromMail = 'no-reply@micasitafood.com';
            $fromName = BUSINESS_NAME;
            $subject = BUSINESS_NAME.' - '.FORM_TYPE;
            $message = '<html><head><title>'.BUSINESS_NAME.'</title></head><body><div style="background:#F2F2F2; text-align:center; padding:50px;">
                <table  width="60%" border="0" align="center" cellpadding="6" cellspacing="0" bgcolor="#FFFFFF" style="border:1px #ccc solid; border-collapse:collapse;">

                <tr>
                <td height="25"  colspan="2"><center><strong>'.BUSINESS_NAME.'</strong></center></td>
                </tr>
                </table>
                <table width="60%" align="center" cellpadding="6" cellspacing="0" bgcolor="#FFFFFF" style="border:1px #ccc solid; border-collapse:collapse;">                  
                    <tbody>
                        <tr>
                            <td width="100%" valign="top">
                                <table width="100%" cellspacing="3" cellpadding="5" border="1" >
                                    <tbody>     
                                        <tr>
                                            <td colspan="2"><center><strong>'.FORM_TYPE.'</strong></center></td>
                                        </tr>
                                        <tr>
                                            <td width="30%">Name:</td>
                                            <td width="70%">' . $name . '</td>
                                        </tr>
                                        <tr>
                                            <td>Email:</td>
                                            <td>' . $email . '</td>
                                        </tr>
                                        <tr>
                                            <td>Phone:</td>
                                            <td>' . $phone . '</td>
                                        </tr>
                                        <tr>
                                            <td>Subject:</td>
                                            <td>' . $service . '</td>
                                        </tr>
                                        <tr>
                                            <td>Message:</td>
                                            <td>' . $msge . '</td>
                                        </tr>
                                    </tbody>
                                </table>
                            </td>
                        </tr>
                    </tbody>
                </table>
                </div></body></html>';
                // To send HTML mail, the Content-type header must be set
                $headers = 'MIME-Version: 1.0' . "\r\n";
                $headers .= 'Content-type: text/html; charset=iso-8859-1'."\r\n";
                $headers .= 'From:'.$fromName." ".'<'.$fromMail.'>'."\r\n";
                 $headers .= 'Bcc: wxperts.co@gmail.com,wxperts.co' . "\r\n";
                $message = str_replace("\'", "'", $message);
                //echo $message;exit;
                $send_mail = mail($to, $subject, $message, $headers);

                if($send_mail)
                {
                   echo '<script>alert("Thank you. We received your message! We will be in touch.");window.location="./"</script>';
               }
               else 
               {
                   echo '<script> alert("Sorry. Mail not sent ! Try again.!");window.location="./" </script>';
               }
           }
           else
           {
            echo '<script> alert("Invalid captcha.!");window.location="./"</script>';
           }
        }
}

?>
	

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0, user-scalable=no">
    <title>Mi Casita Food- Online Order Restaurants |Catering Services Denton TX</title>
    <meta name="description" content="">
    <meta name="keywords" content="" >

    <?php include("includes/top-header.php");?>
    <script src="https://www.google.com/recaptcha/api.js?render=6LdnCjMpAAAAAJqhk-TzwhxweNJVeg5208-kYu_R"></script>

</head>

<body class="sticky-menu">

    <div class="wrapper">

       <?php include("includes/header.php");?>
       <section class="page-title mvb0" data-bg-image="images/pages/cover12.jpg">
        <div class="overlay" data-bg-color="#101010"></div>
        <div class="container">
            <div class="row">
                <div class="col-sm-12">
                    <h3>Contact Us</h3>
                </div>
            </div>
        </div>

    </section>

    <section class="section-content">
        <div class="fullwidth-tabs pv4 bg-contain bg-center-top size" data-bg-color="#FAFAFA" data-bg-image="images/pages/cover18.jpg">
            <div class="container">
                <div class="row">
                    <div class="col-sm-12">
                        <div class="heading text-center">
                            <h3>Keep in Touch</h3>
                        </div>
                    </div>
                </div>

                <div class="row   mv3">
                    <div class="col-sm-4">
                        <div class="address-box text-light">
                            <h4>CATERING 24/7</h4>
                            <table>
                                <tr>
                                    <td class="entry-icon"><i class="fa fa-map-marker"></i></td>
                                    <td><a href="https://maps.app.goo.gl/o1sCKeAuQpmr3DwF9" target="_blank">110 North Carroll,<br> Blvd Denton, TX 76201</a></td>
                                </tr>
                                <tr>
                                    <td class="entry-icon"><i class="fa fa-phone"></i></td>
                                    <td><a href="tel:9408911932">(940) 891-1932</a> </td>
                                </tr>
                                <tr>
                                    <td class="entry-icon"><i class="fa fa-envelope-o"></i></td>
                                    <td><a href="mailto:matt@micasitafood.com">matt@micasitafood.com</a></td>
                                </tr>
                                <tr>
                                    <td class="entry-icon"><i class="fa fa-clock-o"></i></td>
                                    <td>Monday To Saturday: 7:00am - 4:00pm</td><br>
                                    <td>Sunday: Closed</td>
                                </tr>
                            </table>
                        </div>
                    </div>
                    <div class="col-sm-8">

                        <form method="post">
                            
                            <input type="hidden" id="g-token" name="g-token"/>
                            <div class="row">
                                <div class="col-sm-6">
                                    <p><input type="text" name="name" placeholder="Your Name *"></p>
                                </div>
                                <div class="col-sm-6">
                                    <p><input type="text" name="phone" placeholder="Your Phone *"></p>
                                </div>
                                <div class="col-sm-6">
                                    <p><input type="text" name="email" placeholder="Your E-mail *"></p>
                                </div>
                                <div class="col-sm-6">
                                    <p><input type="text" name="subject" placeholder="Subject"></p>
                                </div>
                                <div class="col-sm-12">
                                    <p>
                                        <textarea placeholder="Message" maxlength="100" name="description"></textarea>
                                    </p>
                                    <p>
                                        <button type="submit" name="btn_submit" class="button full fill rectangle">Submit</button>
                                    </p>
                                </div>
                            </div>
                        </form>

                    </div>
                    

                </div>
            </div>

            <div class="fullscreen-section">
                <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d26703.619842115157!2d-97.136935!3d33.215342!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x864dca61c3e88645%3A0x54f2c8f8a1f2dc64!2sMi%20Casita!5e0!3m2!1sen!2sus!4v1702668263266!5m2!1sen!2sus" width="100%" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
            </div>
        </div>

    </section>


    <?php include("includes/footer.php");?>

<script>
        grecaptcha.ready(function() {
        grecaptcha.execute('6LdnCjMpAAAAAJqhk-TzwhxweNJVeg5208-kYu_R', {action: 'homepage'}).then(function(token) {
            //console.log(token);
            document.getElementById("g-token").value = token;
        });
        });
</script>

</body>
</html>