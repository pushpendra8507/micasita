<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0, user-scalable=no">
    <title>Mi Casita Food- Online Order Restaurants |Catering Services Denton TX</title>
    <meta name="description" content="">
    <meta name="keywords" content="" >

    <?php include("includes/top-header.php");?>

</head>

<body class="sticky-menu">

    <div class="wrapper">

       <?php include("includes/header.php");?>

        <section class="section-content">

            <div class="content-full">


                <div class="fullscreen-section pv3 bg-cover bg-center-top" data-bg-image="images/pages/cover1.jpg">
                    <div class="pv13"></div>
                    <div class="text-center pv3">
                        <video autoplay="autoplay" id="movie" loop="loop" muted="muted" playsinline="playsinline" preload="preload" class="video-style">  
                            <source src="video/video-1.mp4" type="video/mp4"/>
                        </video>
                    </div>
                    <div class="text-center">
                        <span class="mouse-wheel"><h3>Click To Scroll</h3></span>
                    </div>
                </div>


                <div class="fullscreen-section pv14 bg-cover bg-center-center" data-bg-image="images/pages/cover3.jpg">
                    <div class="container pv3">
                        <div class="row">
                            <div class="col-md-12 pv6">

                                <div class="heading text-light text-center">
                                    <h3>Mi Casita</h3>
                                    <h4>Mexican Food</h4>
                                </div>

                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-6 col-sm-offset-3 text-light text-center">
                               <p>Satisfy your craving for authentic Mexican cuisine with the best food in town - at Mi Casita. All of our entrees from breakfast to dinner are made with the freshest ingredients available. All of our items are prepared with vegetarian ingredients. Our beans are made without lard and our rice is cooked without chicken broth.</p>
                           </div>
                       </div>
                   </div>
               </div>

               <div class="fullscreen-section" data-bg-image="images/pages/cover2.jpg">
                <div class="container pv12 section-meet-our-chef" data-bg-image="images/pages/chef.png">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="heading text-center">
                                <h3>Meet Our</h3>
                                <h4>Chef</h4>
                                <div class="line img-icon">
                                    <img src="images/svg/cook-hat.svg" alt="svg icon" data-width="20px">
                                </div>
                            </div>
                            <h3 class="white text-center">Mexican Dishes</h3>
                            <p class="white text-center">
                                Whether you are looking for a hearty breakfast option, a satisfying lunch or a traditional Mexican dinner, we have got you covered.
                            </p>

                            <h3 class="white text-center">Expert Catering</h3>
                            <p class="white text-center">
                                Hosting a party or event? Contact the professionals at Mi Casita for exceptional catering services and leave the worries behind!
                            </p>

                            <div class="heading-small mv4">
                                <div>
                                    <h3 class="white">Online Ordering</h3>
                                </div>
                            </div>

                            <p class="text-center">
                                <a href="https://www.ezcater.com/catering/pvt/mi-casita-denton?fcv=1" target="_blank"><img src="images/ezcater-online-ordering.jpg" alt="" data-width="90px"></a>
                                <a href="https://order.online/store/MiCasita-127094/en-US/?hideModal=true&pickup=true" target="_blank"><img src="images/order-online.png" alt="" data-width="90px"></a>
                                <a href="https://www.ubereats.com/dallas/food-delivery/mi-casita/vm1V0E2TT3OpHZWQqi9rNQ" target="_blank"><img src="images/ubereats.jpg" alt="" data-width="90px"></a>
                                <a href="https://zingmyorder.com/restaurants/Mi-Casita-Mexican-Food" target="_blank"><img src="images/zing.jpg" alt="" data-width="90px"></a>
                            </p>

                            <div class="hidden-md hidden-lg">
                                <div class="pv16"></div>
                                <div class="pv16 hidden-xs"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="fullscreen-section pv6 bg-cover bg-center-top" data-bg-image="images/pages/cover16.jpg">
                <div class="container-large">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="heading text-center">
                                <h3>Our Gallery</h3>
                                <div class="line img-icon">
                                    <img src="images/svg/cook-hat.svg" data-width="20px" alt="svg icon">
                                </div>
                            </div>


                        </div>
                    </div>
                </div>
                <div class="team-carousel">
                    <div class="swiper-container">
                        <div class="swiper-wrapper">
                            <div class="swiper-slide">
                             <div class="portfolio-item">
                                <img src="images/gallery-1.jpg" alt="">
                                <div class="entry-hover">
                                    <div class="entry-meta">
                                        <h3>Mi Casita</h3>
                                        <a href="gallery.php" class="post-link">View more</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="swiper-slide">
                         <div class="portfolio-item">
                            <img src="images/gallery-2.jpg" alt="">
                            <div class="entry-hover">
                                <div class="entry-meta">
                                    <h3>Mi Casita</h3>
                                    <a href="gallery.php" class="post-link">View more</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide">
                     <div class="portfolio-item">
                        <img src="images/gallery-3.jpg" alt="">
                        <div class="entry-hover">
                            <div class="entry-meta">
                                <h3>Mi Casita</h3>
                                <a href="gallery.php" class="post-link">View more</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="swiper-slide">
                     <div class="portfolio-item">
                        <img src="images/gallery-4.jpg" alt="">
                        <div class="entry-hover">
                            <div class="entry-meta">
                                <h3>Mi Casita</h3>
                                <a href="gallery.php" class="post-link">View more</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="swiper-slide">
                     <div class="portfolio-item">
                        <img src="images/gallery-5.jpg" alt="">
                        <div class="entry-hover">
                            <div class="entry-meta">
                                <h3>Mi Casita</h3>
                                <a href="gallery.php" class="post-link">View more</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="swiper-slide">
                     <div class="portfolio-item">
                        <img src="images/gallery-6.jpg" alt="">
                        <div class="entry-hover">
                            <div class="entry-meta">
                                <h3>Mi Casita</h3>
                                <a href="gallery.php" class="post-link">View more</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="swiper-slide">
                     <div class="portfolio-item">
                        <img src="images/gallery-7.jpg" alt="">
                        <div class="entry-hover">
                            <div class="entry-meta">
                                <h3>Mi Casita</h3>
                                <a href="gallery.php" class="post-link">View more</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="swiper-slide">
                     <div class="portfolio-item">
                        <img src="images/gallery-8.jpg" alt="">
                        <div class="entry-hover">
                            <div class="entry-meta">
                                <h3>Mi Casita</h3>
                                <a href="gallery.php" class="post-link">View more</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="swiper-slide">
                     <div class="portfolio-item">
                        <img src="images/gallery-9.jpg" alt="">
                        <div class="entry-hover">
                            <div class="entry-meta">
                                <h3>Mi Casita</h3>
                                <a href="gallery.php" class="post-link">View more</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="swiper-slide">
                     <div class="portfolio-item">
                        <img src="images/gallery-10.jpg" alt="">
                        <div class="entry-hover">
                            <div class="entry-meta">
                                <h3>Mi Casita</h3>
                                <a href="gallery.php" class="post-link">View more</a>
                            </div>
                        </div>
                    </div>
                </div>
        </div>
        <div class="swiper-pagination"></div>
    </div>
</div>
</div>

<div class="fullscreen-section pv6" data-bg-image="images/pages/cover20.jpg">
    <div class="overlay" data-bg-color="#000" data-alpha="0.4"></div>
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <div class="heading text-center text-light">
                    <h3>Testimonials</h3>
                    <div class="line img-icon">
                        <img src="images/svg/profile.svg" alt="svg icon" data-width="16px">
                    </div>
                </div>

                <div class="swiper-container carousel-container text-light mv6 mvb0">
                    <div class="swiper-wrapper">
                        <div class="swiper-slide">
                        <div class="row">
                            <div class="col-md-8 col-md-offset-2">
                                <div class="testimonial with-avatar text-light">
                                    <p>
                                       A little gem in the heart of Denton! Definitely recommend and such a great family business! The food and service was great! 
                                   </p>

                                   <div class="entry-meta">
                                    <h4>Yuki A</h4>
                                    <a href="https://www.google.com/maps/place/Mi+Casita/@33.215339,-97.136912,14z/data=!4m8!3m7!1s0x864dca61c3e88645:0x54f2c8f8a1f2dc64!8m2!3d33.2153416!4d-97.1369346!9m1!1b1!16s%2Fg%2F1tjfbnym?hl=en-US&entry=ttu" target="_blank"><img src="images/google-reviews.png"></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                    <div class="swiper-slide">
                        <div class="row">
                            <div class="col-md-8 col-md-offset-2">
                                <div class="testimonial with-avatar text-light">
                                    <p>
                                       I love this Mexican restaurant. It's my "go to" place for the breakfast taco combo. Although it's a small establishment, I've never had any issues with finding seating. It's nice, comfortable and the food is fantastic!! The staff is also great. 
                                   </p>

                                   <div class="entry-meta">
                                    <h4>Sherry Harper</h4>
                                    <a href="https://www.google.com/maps/place/Mi+Casita/@33.215339,-97.136912,14z/data=!4m8!3m7!1s0x864dca61c3e88645:0x54f2c8f8a1f2dc64!8m2!3d33.2153416!4d-97.1369346!9m1!1b1!16s%2Fg%2F1tjfbnym?hl=en-US&entry=ttu" target="_blank"><img src="images/google-reviews.png"></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="swiper-slide">
                        <div class="row">
                            <div class="col-md-8 col-md-offset-2">
                                <div class="testimonial with-avatar text-light">
                                    <p>
                                       This was our first visit and we understand why so many people love eating at Mi Casita.  The food is great, the staff is very friendly and the food portions are generous.   We will definitely return for another visit. 
                                   </p>

                                   <div class="entry-meta">
                                    <h4>Salvador Solis</h4>
                                    <a href="https://www.google.com/maps/place/Mi+Casita/@33.215339,-97.136912,14z/data=!4m8!3m7!1s0x864dca61c3e88645:0x54f2c8f8a1f2dc64!8m2!3d33.2153416!4d-97.1369346!9m1!1b1!16s%2Fg%2F1tjfbnym?hl=en-US&entry=ttu" target="_blank"><img src="images/google-reviews.png"></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="swiper-slide">
                        <div class="row">
                            <div class="col-md-8 col-md-offset-2">
                                <div class="testimonial with-avatar text-light">
                                    <p>
                                       Wonderful hidden gem!  Service was wonderful. Employees very nice. We loved the beef crunchy taco & cheese enchilada plates. Hope to try breakfast tacos next time. 
                                   </p>

                                   <div class="entry-meta">
                                    <h4>Nichole Thalji</h4>
                                    <a href="https://www.google.com/maps/place/Mi+Casita/@33.215339,-97.136912,14z/data=!4m8!3m7!1s0x864dca61c3e88645:0x54f2c8f8a1f2dc64!8m2!3d33.2153416!4d-97.1369346!9m1!1b1!16s%2Fg%2F1tjfbnym?hl=en-US&entry=ttu" target="_blank"><img src="images/google-reviews.png"></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="swiper-slide">
                        <div class="row">
                            <div class="col-md-8 col-md-offset-2">
                                <div class="testimonial with-avatar text-light">
                                    <p>
                                       Love this place. They have the best breakfast tacos! And I love that they give you chips and salsa with just about every to go order. 
                                   </p>

                                   <div class="entry-meta">
                                    <h4>Jessica Scott</h4>
                                    <a href="https://www.google.com/maps/place/Mi+Casita/@33.215339,-97.136912,14z/data=!4m8!3m7!1s0x864dca61c3e88645:0x54f2c8f8a1f2dc64!8m2!3d33.2153416!4d-97.1369346!9m1!1b1!16s%2Fg%2F1tjfbnym?hl=en-US&entry=ttu" target="_blank"><img src="images/google-reviews.png"></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
        </div>
        <div class="swiper-pagination"></div>
    </div>

</div>
</div>
</div>
</div>

</div>

</section>


<?php include("includes/footer.php");?>



</body>
</html>