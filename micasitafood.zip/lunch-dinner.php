<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0, user-scalable=no">
    <title>Mi Casita Food- Online Order Restaurants |Catering Services Denton TX</title>
    <meta name="description" content="">
    <meta name="keywords" content="" >

    <?php include("includes/top-header.php");?>

</head>

<body class="sticky-menu">

    <div class="wrapper">

     <?php include("includes/header.php");?>
     <section class="page-title mvb0" data-bg-image="images/pages/cover12.jpg">
        <div class="overlay" data-bg-color="#101010"></div>
        <div class="container">
            <div class="row">
                <div class="col-sm-12">
                    <h3>Lunch / Dinner</h3>
                    <h5>We offer the best dishes for you to enjoy</h5>
                    <h4>*Prices Subject To Change</h4>
                </div>
            </div>
        </div>

    </section>

    <section class="section-content fullscreen-section">

        <div class="fullwidth-tabs pv4 bg-contain bg-center-top size" data-bg-color="#FAFAFA" data-bg-image="images/pages/cover17.jpg">
            <div>
                <div class="container tabs-nav">
                    <div class="row">
                        <div class="col-md-12 text-center">
                            <ul>
                                <li class="active"><a href="javascript:;">Daily Specials</a></li>
                                <li><a href="javascript:;">Mexican Plates</a></li>
                                <li><a href="javascript:;">A La Carte</a></li>
                                <li><a href="javascript:;">Burgers &amp; More</a></li>
                                <li><a href="javascript:;">Grande Burritos</a></li>
                                <li><a href="javascript:;">Nachos</a></li>
                                <li><a href="javascript:;">MI Casita Nachos</a></li>
                                <li><a href="javascript:;">Specialty Tacos</a></li>
                                <li><a href="javascript:;">$2.77 Menu</a></li>
                                <li><a href="javascript:;">Side Orders</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div>
                <div class="container tabs-contents">
                    <div class="tabs-content">
                        <div class="row pv6 pvb0">
                            <div class="col-md-12 mv5 mvt0">

                                <div class="heading text-center">
                                    <h3>Daily Specials</h3>
                                </div>

                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-5 ph3">
                                <div class="food-price">
                                    <h4>Gosh Egg-White Omelet <span class="fp-amount">$8.99</span></h4>
                                </div>
                                <div class="food-price">
                                    <h4>1 Chicken Flauta, 1 Bean Chalupa, 1 Taco,<br> Side of Sour Cream and Guacamole <span class="fp-amount">$8.99</span></h4>
                                </div>
                                <div class="food-price">
                                    <h4>1 Cheese Enchilada, 1 Taco, Rice and Beans <span class="fp-amount">$8.99</span></h4>
                                </div>
                                <div class="food-price">
                                    <h4>Choice of Burrito, Rice and Beans <span class="fp-amount">$8.99</span></h4>
                                </div>
                                <div class="food-price">
                                    <h4>2 Cheese Enchiladas, Rice and Beans <span class="fp-amount">$8.99</span></h4>
                                </div>
                            </div>
                            <div class="col-md-5 ph3">
                                <div class="food-price">
                                    <h4>2 Chicken Flautas, Rice, Beans and<br> Sour Cream <span class="fp-amount">$8.99</span></h4>
                                </div>
                                <div class="food-price">
                                    <h4>2 Quesadillas, Rice, Beans and<br> Sour Cream <span class="fp-amount">$8.99</span></h4>
                                </div>
                                <div class="food-price">
                                    <h4>Hearty Grain Breakfast <span class="fp-amount">$8.99</span></h4>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="tabs-content">
                        <div class="row pv6 pvb0">
                            <div class="col-md-12 mv5 mvt0">
                                <div class="heading text-center">
                                    <h3>Mexican Plates</h3>
                                </div>

                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-5 ph3">
                                <h3 class="sub-head">Enchilada (3) Plates</h3>
                                <div class="food-price">
                                    <h4>Cheese <span class="fp-amount">$9.99</span></h4>
                                </div>
                                <div class="food-price">
                                    <h4>Beef or Chicken <span class="fp-amount">$9.99</span></h4>
                                </div>
                                <div class="food-price">
                                    <h4>Combination <span class="fp-amount">$9.99</span></h4>
                                </div>
                                <div class="food-price">
                                    <h4>Tamale Plate <span class="fp-amount">$9.99</span></h4>
                                </div>


                                <h3 class="sub-head">Tacos (3) Plates</h3>
                                <div class="food-price">
                                    <h4>Bean and Cheese <span class="fp-amount">$9.99</span></h4>
                                </div>
                                <div class="food-price">
                                    <h4>Beef or Chicken <span class="fp-amount">$9.99</span></h4>
                                </div>
                                <div class="food-price">
                                    <h4>Combination (Enchilada and Taco plates<br> served with rice and beans) <span class="fp-amount">$9.99</span></h4>
                                </div>
                              
                            </div>
                            <div class="col-md-5 ph3">
                                <h3 class="sub-head">Flauta (3) Plate</h3>
                                <div class="food-price">
                                    <h4>Chicken or Beef <span class="fp-amount">$9.99</span></h4>
                                </div>
                                
                                <h3 class="sub-head">Quesadillas (3 Plate)</h3>
                                <div class="food-price">
                                    <h4>Plain <span class="fp-amount">$9.99</span></h4>
                                </div>
                                <div class="food-price">
                                    <h4>Beef or Chicken <span class="fp-amount">$9.99</span></h4>
                                </div>
                                <div class="food-price">
                                    <h4>Beef or Chicken Fajita (* Chalupa, Flauta, and Quesadilla Plates served with<br> rice, beans, and side of sour cream) <span class="fp-amount">$10.99</span></h4>
                                </div>
                                <div class="food-price">
                                    <h4>Beef or Chicken <span class="fp-amount">$9.99</span></h4>
                                </div>
                                <div class="food-price">
                                    <h4>Beef or Chicken Fajita <span class="fp-amount">$10.99</span></h4>
                                    <p>Above salads have beans, lettuce, tomato, cheese, meat, and topped with guacamole, sour cream, and jalapenos</p>
                                </div>
                                <div class="food-price">
                                    <h4>Small Guacamole Salad <span class="fp-amount">$7.99</span></h4>
                                </div>
                                <div class="food-price">
                                    <h4>Large Guacamole Salad <span class="fp-amount">$8.99</span></h4>
                                </div>
                              
                            </div>
                        </div>
                    </div>
                    <div class="tabs-content">
                        <div class="row pv6 pvb0">
                            <div class="col-md-12 mv5 mvt0">

                                <div class="heading text-center">
                                    <h3>A La Carte</h3>
                                </div>

                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-5 ph3">
                                <div class="food-price">
                                    <h4>Flauta <span class="fp-amount">$2.69</span></h4>
                                </div>
                                <div class="food-price">
                                    <h4>Bean and Beef Chalupa <span class="fp-amount">$2.99</span></h4>
                                </div>
                                <div class="food-price">
                                    <h4>Bean and Chicken Chalupa <span class="fp-amount">$2.99</span></h4>
                                </div>

                            </div>
                            <div class="col-md-5 ph3">
                                <div class="food-price">
                                    <h4>Plain Quesadilla <span class="fp-amount">$2.49</span></h4>
                                </div>
                                <div class="food-price">
                                    <h4>Beef or Chicken Quesadilla <span class="fp-amount">$2.89</span></h4>
                                </div>
                                <div class="food-price">
                                    <h4>Beef or Chicken Fajita Quesadilla <span class="fp-amount">$3.29</span></h4>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="tabs-content">
                        <div class="row pv6 pvb0">
                            <div class="col-md-12 mv5 mvt0">

                                <div class="heading text-center">
                                    <h3>Burgers &amp; More </h3>
                                </div>

                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-5 ph3">

                                <div class="food-price">
                                    <h4>Hamburger <span class="fp-amount">$5.49</span></h4>
                                </div>
                                <div class="food-price">
                                    <h4>Cheese Burger <span class="fp-amount">$5.99</span></h4>
                                </div>
                                <div class="food-price">
                                    <h4>Bacon Cheese Burger <span class="fp-amount">$7.99</span></h4>
                                </div>
                                <div class="food-price">
                                    <h4>Taco Burger <span class="fp-amount">$5.99</span></h4>
                                </div>

                            </div>
                            <div class="col-md-5 ph3">
                                <div class="food-price">
                                    <h4>BLT <span class="fp-amount">$4.99</span></h4>
                                </div>
                                <div class="food-price">
                                    <h4>Seasoned Curly Fries <span class="fp-amount">$3.79</span></h4>
                                </div>
                                <div class="food-price">
                                    <h4>Gordita <span class="fp-amount">$4.99</span></h4>
                                </div>
                                <div class="food-price">
                                    <h4>Torta <span class="fp-amount">$8.99</span></h4>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="tabs-content">
                        <div class="row pv6 pvb0">
                            <div class="col-md-12 mv5 mvt0">

                                <div class="heading text-center">
                                    <h3>Grande Burritos</h3>
                                </div>

                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-5 ph3">

                                <div class="food-price">
                                    <h4>Bean &amp; Cheese <span class="fp-amount">$6.99</span></h4>
                                </div>
                                <div class="food-price">
                                    <h4>Beef &amp; Cheese <span class="fp-amount">$7.99</span></h4>
                                </div>
                                <div class="food-price">
                                    <h4>Chicken &amp; Cheese <span class="fp-amount">$7.99</span></h4>
                                </div>
                                <div class="food-price">
                                    <h4>Beef or Chicken or Combination Fajitas <span class="fp-amount">$13.99</span></h4>
                                </div>
                                <div class="food-price">
                                    <h4>Barbacoa Plate <span class="fp-amount">$13.99</span></h4>
                                </div>
                                <div class="food-price">
                                    <h4>Carne Guisada Plate <span class="fp-amount">$13.99</span></h4>
                                    <p>Speciality Plates served with rice, beans, lettuce, pico, Guacamole, and cheese</p>
                                </div>
                            </div>
                            <div class="col-md-5 ph3">
                                <div class="food-price">
                                    <h4>Combination <span class="fp-amount">$8.49</span></h4>
                                    <p>(Beans, Choice of Meat, Cheese)</p>
                                    <p>
                                        <span class="fp-title">Served with beans, choice of meat, cheese, guacamole and sour cream</span>
                                        <span class="fp-amount">$8.89</span>
                                    </p>
                                    <p>
                                        <span class="fp-title">Served with beans, rice, cheese, guacamole, sour cream, lettuce and tomato</span>
                                        <span class="fp-amount">$8.89</span>
                                    </p>
                                </div>

                            </div>
                        </div>
                    </div>
                    <div class="tabs-content">
                        <div class="row pv6 pvb0">
                            <div class="col-md-12 mv5 mvt0">

                                <div class="heading text-center">
                                    <h3>Nachos</h3>
                                </div>

                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-5 ph3">

                                <div class="food-price">
                                    <h4>Cheese <span class="fp-amount">$6.49</span></h4>
                                </div>
                                <div class="food-price">
                                    <h4>Bean &amp; Cheese <span class="fp-amount">$7.59</span></h4>
                                </div>
                            </div>
                            <div class="col-md-5 ph3">
                                <div class="food-price">
                                    <h4>Beef &amp; Cheese <span class="fp-amount">$8.59</span></h4>
                                </div>
                                <div class="food-price">
                                    <h4>Chicken &amp; Cheese <span class="fp-amount">$8.59</span></h4>
                                    <p>Served with jalapenos and pico only.</p>
                                </div>

                            </div>
                        </div>
                    </div>
                    <div class="tabs-content">
                        <div class="row pv6 pvb0">
                            <div class="col-md-12 mv5 mvt0">

                                <div class="heading text-center">
                                    <h3>MI Casita Nachos</h3>
                                </div>

                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-5 ph3">
                                <div class="food-price">
                                    <h4>Beef or Chicken <span class="fp-amount">$9.99</span></h4>
                                </div>
                            </div>
                            <div class="col-md-5 ph3">
                                <div class="food-price">
                                    <h4>Beef or Chicken Fajita <span class="fp-amount">$10.99</span></h4>
                                    <p>Served with beans, meat, cheese, guacamole, sour cream, pico, and jalapenos</p>
                                </div>

                            </div>
                        </div>
                    </div>
                    <div class="tabs-content">
                        <div class="row pv6 pvb0">
                            <div class="col-md-12 mv5 mvt0">

                                <div class="heading text-center">
                                    <h3>Specialty Tacos</h3>
                                </div>

                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-5 ph3">
                                <div class="food-price">
                                    <h4>Guacamole Taco <span class="fp-amount">$3.29</span></h4>
                                </div>
                                <div class="food-price">
                                    <h4>Carne Guisada Taco <span class="fp-amount">$3.29</span></h4>
                                </div>
                                <div class="food-price">
                                    <h4>Barbacoa Taco <span class="fp-amount">$3.29</span></h4>
                                </div>
                                <div class="food-price">
                                    <h4>Beef Fajita Taco <span class="fp-amount">$3.29</span></h4>
                                </div>
                                <div class="food-price">
                                    <h4>Chicken Fajita Taco <span class="fp-amount">$3.29</span></h4>
                                </div>
                            </div>
                            <div class="col-md-5 ph3">
                                <div class="food-price">
                                    <h4>Fish Taco <span class="fp-amount">$3.29</span></h4>
                                </div>
                                <div class="food-price">
                                    <h4>Carnita Taco <span class="fp-amount">$3.29</span></h4>
                                </div>
                                <div class="food-price">
                                    <h4>Street Taco <span class="fp-amount">$3.29</span></h4>
                                </div>
                                <div class="food-price">
                                    <h4>Carne Asada Taco <span class="fp-amount">$3.29</span></h4>
                                </div>

                            </div>
                        </div>
                    </div>
                    <div class="tabs-content">
                        <div class="row pv6 pvb0">
                            <div class="col-md-12 mv5 mvt0">

                                <div class="heading text-center">
                                    <h3>$2.77 Menu</h3>
                                </div>

                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-5 ph3">
                                <div class="food-price">
                                    <h4>Beans & Cheese Taco <span class="fp-amount">$2.77</span></h4>
                                </div>
                                <div class="food-price">
                                    <h4>Beef Taco (Soft or Crispy) <span class="fp-amount">$2.77</span></h4>
                                </div>
                                <div class="food-price">
                                    <h4>Chicken (Soft or Crispy) <span class="fp-amount">$2.77</span></h4>
                                </div>
                            </div>
                            <div class="col-md-5 ph3">
                                <div class="food-price">
                                    <h4>Beans Chalupa <span class="fp-amount">$2.77</span></h4>
                                </div>
                                <div class="food-price">
                                    <h4>Rice <span class="fp-amount">$2.77</span></h4>
                                </div>
                                <div class="food-price">
                                    <h4>Beans <span class="fp-amount">$2.77</span></h4>
                                </div>

                            </div>
                        </div>
                    </div>
                    <div class="tabs-content">
                        <div class="row pv6 pvb0">
                            <div class="col-md-12 mv5 mvt0">

                                <div class="heading text-center">
                                    <h3>Side Orders</h3>
                                </div>

                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-5 ph3">
                                <div class="food-price">
                                    <h4>Large Chips & Salsa <span class="fp-amount">$4.59</span></h4>
                                </div>
                                <div class="food-price">
                                    <h4>Small Chips & Salsa <span class="fp-amount">$3.49</span></h4>
                                </div>
                                <div class="food-price">
                                    <h4>Large Chips & Queso <span class="fp-amount">$5.99</span></h4>
                                </div>
                                <div class="food-price">
                                    <h4>Small Chips & Queso <span class="fp-amount">$3.99</span></h4>
                                </div>
                                <div class="food-price">
                                    <h4>Guacamole (2 oz) <span class="fp-amount">$1.99</span></h4>
                                </div>
                                <div class="food-price">
                                    <h4>Sour Cream (2 oz) <span class="fp-amount">$0.89</span></h4>
                                </div>
                                <div class="food-price">
                                    <h4>Jalapeno (2 oz) <span class="fp-amount">$0.89</span></h4>
                                </div>
                            </div>
                            <div class="col-md-5 ph3">
                                <div class="food-price">
                                    <h4>Pico (2 oz) <span class="fp-amount">$0.89</span></h4>
                                </div>
                                <div class="food-price">
                                    <h4>Cheese <span class="fp-amount">$0.89</span></h4>
                                </div>
                                <div class="food-price">
                                    <h4>Hot Sauce (32 oz) <span class="fp-amount">$8.49</span></h4>
                                </div>
                                <div class="food-price">
                                    <h4>Hot Sauce (16oz) <span class="fp-amount">$5.59</span></h4>
                                </div>
                                <div class="food-price">
                                    <h4>Hot Sauce (8oz) <span class="fp-amount">$3.99</span></h4>
                                </div>
                                <div class="food-price">
                                    <h4>3 Flour Tortillas <span class="fp-amount">$1.39</span></h4>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>


    </div>

</section>


<?php include("includes/footer.php");?>



</body>
</html>