<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0, user-scalable=no">
    <title>Mi Casita Food- Online Order Restaurants |Catering Services Denton TX</title>
    <meta name="description" content="">
    <meta name="keywords" content="" >

    <?php include("includes/top-header.php");?>

</head>

<body class="sticky-menu">

    <div class="wrapper">

     <?php include("includes/header.php");?>
     <section class="page-title mvb0" data-bg-image="images/pages/cover12.jpg">
        <div class="overlay" data-bg-color="#101010"></div>
        <div class="container">
            <div class="row">
                <div class="col-sm-12">
                    <h3>Gallery</h3>
                </div>
            </div>
        </div>

    </section>

    <section class="section-content">


        <div class="fullscreen-section">
            <div class="portfolio-container masonry" data-col-width=".col-md-4">
                <div class="col-xs-12 col-sm-6 col-md-4 ph0 masonry-item">
                    <div class="portfolio-item">
                        <img src="images/gallery-11.jpg" alt="">
                    </div>
                </div>
                <div class="col-xs-12 col-sm-6 col-md-4 ph0 masonry-item">
                    <div class="portfolio-item">
                        <img src="images/gallery-12.jpg" alt="">
                    </div>
                </div>
                <div class="col-xs-12 col-sm-6 col-md-4 ph0 masonry-item">
                    <div class="portfolio-item">
                        <img src="images/gallery-13.jpg" alt="">
                    </div>
                </div>
                <div class="col-xs-12 col-sm-6 col-md-4 ph0 masonry-item">
                    <div class="portfolio-item">
                        <img src="images/gallery-14.jpg" alt="">
                    </div>
                </div>
                <div class="col-xs-12 col-sm-6 col-md-4 ph0 masonry-item">
                    <div class="portfolio-item">
                        <img src="images/gallery-15.jpg" alt="">
                    </div>
                </div>
                <div class="col-xs-12 col-sm-6 col-md-4 ph0 masonry-item">
                    <div class="portfolio-item">
                        <img src="images/gallery-16.jpg" alt="">
                    </div>
                </div>
                <div class="col-xs-12 col-sm-6 col-md-4 ph0 masonry-item">
                    <div class="portfolio-item">
                        <img src="images/gallery-17.jpg" alt="">
                    </div>
                </div>
                <div class="col-xs-12 col-sm-6 col-md-4 ph0 masonry-item">
                    <div class="portfolio-item">
                        <img src="images/gallery-18.jpg" alt="">
                    </div>
                </div>
                <div class="col-xs-12 col-sm-6 col-md-4 ph0 masonry-item">
                    <div class="portfolio-item">
                        <img src="images/gallery-19.jpg" alt="">
                    </div>
                </div>
                <div class="col-xs-12 col-sm-6 col-md-4 ph0 masonry-item">
                    <div class="portfolio-item">
                        <img src="images/gallery-20.jpg" alt="">
                    </div>
                </div>
                <div class="col-xs-12 col-sm-6 col-md-4 ph0 masonry-item">
                    <div class="portfolio-item">
                        <img src="images/gallery-21.jpg" alt="">
                    </div>
                </div>
                <div class="col-xs-12 col-sm-6 col-md-4 ph0 masonry-item">
                    <div class="portfolio-item">
                        <img src="images/gallery-22.jpg" alt="">
                    </div>
                </div>
                
            </div>



        </div>

    </section>


    <?php include("includes/footer.php");?>



</body>
</html>